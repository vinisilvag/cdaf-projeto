# cdaf-projeto

## Como rodar

Extrar os arquivos `events.zip` e `matches.zip`.

Em seguida:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip3 install -r requirements.txt
```
